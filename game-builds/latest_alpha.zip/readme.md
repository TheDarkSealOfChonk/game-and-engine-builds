double click run.bat or Egon Rise Of The Angels.exe to start without updating.
to update and start double click latest_alpha_installer.bat